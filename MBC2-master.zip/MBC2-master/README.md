
  
[2تـنـصـيــب ســورس ام بـي سـي]
 
```sh

افتـح ترمنـــأل وخلي   

sudo apt-get update 
======================
ورهأَ خلي  

redis-server
======================
تركه مفتوح    
وفتح ترمنال ثاني وخلي    
    
sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev libjansson* libpython-dev make unzip git redis-server g++ -y --force-yes
======================
ورأهأَ خلي  

git clone https://github.com/zfu2/MBC2.git
======================
ورهأ خلي    

cd MBC2
======================
ورهأَ خلي 
======================
chmod +x MBC2.sh
======================
ورهأَ خلي 

./MBC2.sh install
 
======================
راح تطلعلك كتابه
[N,Y] 
Y خلي
======================
ورهأَ خلي  

./MBC2.sh
======================
يطلب رقم خلي رقم البوت  

اي شي تحتاج تعال هنا
https://telegram.me/Cr7rC
```


لتنصيب البوـب بكوَدَ واحد فقط َ   

فتح ترمنال وخلي   
======================
sudo apt-get update 
======================
ورهأَ خلي  

redis-server
======================
تركه مفتوح   

وفتح ترمنال ثاني وخلي  
```sh

sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev libjansson* libpython-dev make unzip git redis-server g++ -y --force-yes && git clone https://github.com/zfu2/MBC2.git && cd MBC2 && chmod +x MBC2.sh && ./MBC2.sh install && ./MBC2.sh
```

======================

يطلب رقم خلي رقم البوت 


 وراها روح لحافظة داتا وراها ملف كونفج خلي ايديك
```
  sudo_users = {
    60210262,
    YourID
  }
```
وراها روح لحافظة بوت وراها ملف بوت خلي ايدي
بالسطر المرقم (77) حته تكدر ترفع مطور بالاوامر
 ```
 sudo_users = {60210262},
    admins = {},
 ```
اي شي تحتاج تعال هنا

https://telegram.me/Cr7rC
